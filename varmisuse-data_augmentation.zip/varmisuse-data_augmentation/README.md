## Dataset for augmentation - Variable Misuse tool

This folder contains the processed dataset that was obtained after the corresponding treatment of the source code files extracted from third-party repositories that have been used for augmenting training data for the Variable Miuse tool belonging to the DECODER project. This dataset includes not only the correct programs, but also synthetically created buggy files.

Third-party projects are not attached due to the different licenses they use. You can find them on these Zenodo repositories:
* Variable Misuse tool: Dataset for data augmentation (2): https://doi.org/10.5281/zenodo.6090310
* Variable Misuse tool: Dataset for data augmentation (3): https://doi.org/10.5281/zenodo.6090340
* Variable Misuse tool: Dataset for data augmentation (4): https://doi.org/10.5281/zenodo.6090379
* Variable Misuse tool: Dataset for data augmentation (5): https://doi.org/10.5281/zenodo.6090423
* Variable Misuse tool: Dataset for data augmentation (6): https://doi.org/10.5281/zenodo.6090482
* Variable Misuse tool: Dataset for data augmentation (7): https://doi.org/10.5281/zenodo.6090582
